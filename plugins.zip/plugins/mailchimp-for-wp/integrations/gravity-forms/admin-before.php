<p>
    <?php echo sprintf( __( 'To integrate with Gravity Forms, add the "MailChimp" field to <a href="%s">one of your Gravity Forms forms</a>.', 'mailchimp-for-wp' ), admin_url( 'admin.php?page=gf_edit_forms' ) ); ?>
</p>